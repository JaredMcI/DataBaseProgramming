create view BIGPOLICIES as
  Select Policy_No Type, premium_AMT
  FROM Policies
  Where PREMIUM_AMT > 50
/

