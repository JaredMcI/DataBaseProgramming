create PROCEDURE SearchByGenre(
cursorParam OUT SYS_REFCURSOR, genre IN VARCHAR2)
AS
m_name Media.Name%Type;
m_Averagerating MEDIA.AVERAGERATING%Type;
m_PrimaryGenre  MEDIA.PRIMARYGENRE%Type;


BEGIN

  OPEN cursorParam FOR
  SELECT
  MEDIA.Name,
  MEDIA.AVERAGERATING,
  MEDIA.PRIMARYGENRE, 
  INTO m_name,m_AverageRating, m_PrimaryGenre 
FROM Media
  Where PrimaryGenre = genre;
END;





-- Running Procedure to find all films with 'Paul' as an actor
/

