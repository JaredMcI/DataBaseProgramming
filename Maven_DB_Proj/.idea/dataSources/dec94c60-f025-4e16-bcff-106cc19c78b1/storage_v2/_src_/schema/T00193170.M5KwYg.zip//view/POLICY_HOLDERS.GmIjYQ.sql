create view POLICY_HOLDERS as
  SELECT Policy_No , Start_Date, Type Surname, forename
  FROM POLICIES P JOIN Holders H ON P.Holder_ID = H.HOLDER_ID
  ORDER BY Surname, Forename
/

