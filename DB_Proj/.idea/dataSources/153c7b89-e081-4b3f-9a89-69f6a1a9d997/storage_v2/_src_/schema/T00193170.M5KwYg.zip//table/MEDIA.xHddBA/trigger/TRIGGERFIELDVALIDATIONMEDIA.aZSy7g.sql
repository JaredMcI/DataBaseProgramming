create trigger TRIGGERFIELDVALIDATIONMEDIA
  before insert or update
  on MEDIA
  for each row
  DECLARE
T_Name "MEDIA".Name%type;
T_Description "MEDIA".Description%type;
T_YEARRELEASED "MEDIA".YearReleased%type;
T_AGERATING "MEDIA".AgeRating%type;
T_BUDGET "MEDIA".Budget%type;
T_PRIMARYGENRE "MEDIA".PrimaryGenre%type;
T_SECONDARYGENRE "MEDIA".SecondaryGenre%type;
T_MEDIATYPE "MEDIA".MediaType%type;
T_PLATFORM "MEDIA".Platform%type;
T_AVERAGERATING "MEDIA".AverageRating%type;

BEGIN 
T_Name := :new.Name;
T_Description := :new.Description;
T_YearReleased := :new.YearReleased;
T_AGERATING := :new.AgeRating;
T_BUDGET := :new.Budget;
T_PRIMARYGENRE := :new.PrimaryGenre;
T_SECONDARYGENRE := :new.SecondaryGenre;
T_MEDIATYPE := :new.MediaType;
T_PLATFORM := :new.Platform;
T_AVERAGERATING := :new.AverageRating;

  --Lengths
  IF(LENGTH(T_Name) > 40) THEN
    RAISE_APPLICATION_ERROR(-200016,'Error - Title too long, must be less than 40 characters');
  ELSIF(LENGTH(T_Description) > 200) THEN
    RAISE_APPLICATION_ERROR(-200017,'Error - Description too long, must be less than 200 characters');
  ELSIF(LENGTH(T_YearReleased) > 4 ) THEN
    RAISE_APPLICATION_ERROR(-200018,'Error - Year Released too long, must be less than 4 characters');
  ELSIF(LENGTH(T_AgeRating) > 5 ) THEN
    RAISE_APPLICATION_ERROR(-200019,'Error - AgeRating too long, must be less than 5 characters');
  ELSIF(LENGTH(T_Budget) > 10 ) THEN
    RAISE_APPLICATION_ERROR(-20020, 'Error - Budget too long, must be less than 10 characters');
  ELSIF(LENGTH(T_Platform) > 15 ) THEN
    RAISE_APPLICATION_ERROR(-20020,'Error - Platform too long, must be less than 15 characters');
  
  
  --Regex
   ELSIF NOT REGEXP_LIKE (T_YearReleased, '^[0-9]*$') THEN
    RAISE_APPLICATION_ERROR(-20021,'Error - Invalid characters entered in Year Released. Only numeric allowed');
  ELSIF NOT REGEXP_LIKE (T_Budget, '^[a-zA-Z\s]+$') THEN
    RAISE_APPLICATION_ERROR(-20022,'Error - Invalid characters entered in Budget, Only numeric allowed');
 
  
    
 END IF;
END;
/

