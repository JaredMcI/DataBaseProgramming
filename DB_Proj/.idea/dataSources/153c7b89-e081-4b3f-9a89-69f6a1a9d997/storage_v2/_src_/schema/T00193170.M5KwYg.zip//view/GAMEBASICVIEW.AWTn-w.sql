create view GAMEBASICVIEW as
  SELECT Name,YearReleased,Platform,AverageRating
FROM MEDIA
WHERE MediaType = 'G'
/

