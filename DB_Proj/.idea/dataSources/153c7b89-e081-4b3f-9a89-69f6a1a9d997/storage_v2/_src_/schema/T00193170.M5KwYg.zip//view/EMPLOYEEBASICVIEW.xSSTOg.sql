create view EMPLOYEEBASICVIEW as
  SELECT Name, Role 
From Employee
/

