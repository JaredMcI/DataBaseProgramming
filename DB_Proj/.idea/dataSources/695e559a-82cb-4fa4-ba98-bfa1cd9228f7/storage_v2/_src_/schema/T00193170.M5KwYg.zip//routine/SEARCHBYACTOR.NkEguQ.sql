create PROCEDURE SearchByActor(
cursorParam OUT SYS_REFCURSOR, CastMemberName IN VARCHAR2)
AS
m_name Media.Name%Type;
m_Averagerating MEDIA.AVERAGERATING%Type;
m_PrimaryGenre  MEDIA.PRIMARYGENRE%Type;
e_name EMPLOYEE.NAME%Type;
--COMPILES with these abscent, only here to allow for the into clause to put data.

BEGIN

  OPEN cursorParam FOR
  SELECT
  MEDIA.Name,
  MEDIA.AVERAGERATING,
  MEDIA.PRIMARYGENRE,
  EMPLOYEE.NAME 
  INTO m_name,m_AverageRating, m_PrimaryGenre, e_name
  --Keep Getting an issue where an INTO clause is required, it compiles 'With an error', Adding into clause on my only select, issue still happens.... CANNOT COMPREHEND WHY.
FROM
  EMPLOYEE
INNER JOIN CAST
ON
  EMPLOYEE.EMPLOYEEID = CAST.EMPLOYEEID
INNER JOIN MEDIA
ON
  MEDIA.MEDIAID = CAST.MEDIAID
  Where Employee.name = CastMemberName;

END;
/

