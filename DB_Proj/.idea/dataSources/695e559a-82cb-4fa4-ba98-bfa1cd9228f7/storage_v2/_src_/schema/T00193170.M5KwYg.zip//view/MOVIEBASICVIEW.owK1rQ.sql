create view MOVIEBASICVIEW as
  SELECT Name,YearReleased,AverageRating
FROM MEDIA
WHERE MediaType = 'F'
/

